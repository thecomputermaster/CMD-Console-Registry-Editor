﻿
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Exercise36
{
    public static void Main(string[] args)
    {
        Console.Write("Input a number between 1 and 25: ");
        int m = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(((m >= 1 && m <= 25)));
        Console.WriteLine("CheckForNullPassed.");

        Assert.IsTrue((m >= 1 && m <= 25));
        Console.WriteLine("CheckForNullPassed");





        catch (FileNotFoundException e)
        {
            // FileNotFoundExceptions are handled here.
        }
        catch (IOException e)
        {
            // Extract some information from this exception, and then 
            // throw it to the parent method.
            if (e.Source != null)
                Console.WriteLine("IOException source: {0}", e.Source);

            throw;
        }


        {
            int num1 = 5;
            int num2 = 0;
            try
            {
                Console.WriteLine(num1 / num2);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Division of {0} by zero.", num1);
            }
        } 
    }

}


    
    